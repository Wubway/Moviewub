import { NotFoundPart } from "@/pages/parts/errors/NotFoundPart";

export function NotFoundPage() {
  return <NotFoundPart />;
}
